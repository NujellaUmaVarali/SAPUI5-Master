sap.ui.define([
	"com/incture/cherrywork/ConferenceData/test/unit/controller/Conf.controller"
], function () {
	"use strict";
});